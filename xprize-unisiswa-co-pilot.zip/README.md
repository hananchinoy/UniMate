# UniMate AI — Automated Student Transit & Cost-of-Living Optimizer
> **XPRIZE AI Hackathon Submission**
> **Selected Category:** Workforce & Economic Empowerment / AI-Operated Consumer Utility
> **Cloud Infrastructure:** Google Cloud Run, Google Gemini Multimodal Vision, Google Maps Platform

---

## 🚀 Overview & Architecture

UniMate AI is an autonomous, AI-operated daily cost-of-living and urban transit intelligence system engineered for university students across Malaysian metropolitan campuses (Universiti Malaya, Sunway, Monash, Taylor's, APU, UKM).

The application runs as a production-grade full-stack Node.js + React + Express architecture deployed continuously on **Google Cloud Run**:
- **Continuous AI Agent Engine**: Powered by Google's `@google/genai` Gemini Multimodal model for automated Malaysian Interbank transfer verification and real-time transit surge mitigation.
- **Multimodal Receipt Verification**: Analyzes bank confirmation slips from Maybank, CIMB, Touch 'n Go, and DuitNow transfers in real time.
- **Zero-Friction Live Ledger**: Transparent, auditable public ledger API endpoints for XPRIZE and Hackathon review.

---

## 🛠️ How to Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Run the development server (Binds to 0.0.0.0:3000)
npm run dev

# 3. Build for production (compiles React + esbuild CommonJS server)
npm run build

# 4. Start production container server
npm start
```

---

## 📡 Live XPRIZE Audit Endpoints

- **Registered Student Users:** `GET /api/auth/registered-users`
- **Verified Payment & Revenue Ledger:** `GET /api/payment/submissions`
- **Transit & Meal Recommendations:** `POST /api/transit/recommendations`
